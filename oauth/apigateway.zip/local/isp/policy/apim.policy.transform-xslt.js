// * Licensed Materials - Property of IBM
// * 5725-L30, 5725-Z22, 5725-Z63, 5725-U33
// *
// * (C) Copyright IBM Corporation 2016, 2017
// *
// * US Government Users Restricted Rights - Use, duplication, or
// * disclosure restricted by GSA ADP Schedule Contract with IBM Corp.

var apim = require('local:///isp/policy/apim.custom.js');
var errs = require('local:///isp/policy/apim.exception.js');
var transform = require('transform');

var dbglog = apim.console;
var verbose = apim.verbose;

var policy = apim.getPolicyProperty();
var input;

var logPrefix = 'apim.transform-xslt';

if (policy.input===undefined) {
    input = false;
} else {
    input = policy.input;
}

var _apimgmt = session.name('_apimgmt');
var poHasOutput = _apimgmt.getVar('use-policy-output');
var mediaType = _apimgmt.getVar('policy-output-mediaType');
if (!poHasOutput) {
  mediaType = require('header-metadata').current.get('Content-Type');
}
if (verbose) dbglog.debug(logPrefix+' apim.transform-xslt: mediaType=' + mediaType + ' poHasOutput=' + poHasOutput);

try {
  if (verbose) {
    var lines = policy.source.split('\n');
    for (var line in lines) {
      if (lines.hasOwnProperty(line)) {
        dbglog.debug(logPrefix+' apim.transform-xslt: ' + lines[line]);
      }
    }
    dbglog.debug(logPrefix+' apim.transform-xslt: input = ' + input);
  }

  if (policy.source.indexOf(":gatewayscript") != -1)
    throw new Error("Error: Certain extension functions such as dp:gatewayscript are unavailable");

  var policyxslt = session.name('policyxslt') || session.createContext('policyxslt');
  policyxslt.write(policy.source);

  if (input) {
      processInputData(mediaType);
  } else {
      transformXSLT(undefined);
  }
}

catch (exception) {
  apim.console.error('apim.transform-xslt: ' + exception);
  apim.error(errs.Errors.TransformError,'500','Internal Error',exception);
}

function processInputData(mediaType, options) {
    if (verbose) dbglog.debug(logPrefix+" we are in processInputData with mediatype = " + mediaType);
    if (mediaType !== undefined) {
        if (apim.isXML(mediaType)) {
            apim.readInputAsXML(function(error, inputdata) {
                if (verbose) {
                    dbglog.debug(logPrefix + ' XML data = '+XML.stringify(inputdata));
                }
                readInputCallback(error, inputdata);
            });
        } else {
            if (apim.isJSON(mediaType)) {
                apim.error(errs.Errors.TransformError, 500, 'Internal error', 'Unable to execute XSLT with JSON content type, type is '+mediaType);
            } else {
                // we have some other type that we cannot
                apim.error(errs.Errors.TransformError, 500, 'Internal error', 'Unable to execute XSLT with non XML content type, type is '+mediaType);
            }
        }
    } else {
        apim.error(errs.Errors.TransformError, 500, 'Internal error', 'Unable to execute XSLT with non XML content type');
    }
}

function readInputCallback(error, xmldata) {
    if (error) {
        apim.error(errs.Errors.TransformError, 500, 'Internal error', 'Error attempting to read the input data');
    } else {
        transformXSLT(xmldata);
    }
}

function transformXSLT(xmldata) {
    var xsltOption = {
            'location': 'var://context/policyxslt',
            'honorAbort': true
    };

    if (xmldata!==undefined) {
        var xmlNode = xmldata;
//@@ BZ50837 us item(0).ownerDocument to ensure that namespaces
//@@ are kept and processed
        xsltOption.xmldom = xmlNode.item(0).ownerDocument;
    }

    // start the xslt execution with the xsltOption
    transform.xslt(xsltOption, function(error, nodelist, isAbort) {
        if (error) {
            apim.error(errs.Errors.TransformError, 500, 'Internal error', JSON.stringify(error));
        } else {
            // if xslt execution was success, the transformation result will be
            // put into the nodelist (a DOM NodeList structure)
            if (nodelist && nodelist.length > 0) {
                if (verbose) {
                    dbglog.debug(logPrefix + ' transformXSLT: we have data ['+XML.stringify(nodelist)+']');
                }
                var context = session.name('_apimgmt');
                // if the called xslt did an apim:output template call, no need to do that implicitly
                // only need to write it to the output context
                if (context.getVariable('policy-output-set') === 'true') {
                  var result = nodelist;
                  // if the mediaType set by the called xslt is non-xml, convert the transform.xslt nodelist result
                  // to a string.  Otherwise, leave it as is, they could be outputting xml
                  var poMediaType = context.getVariable('policy-output-mediaType');
                  if (!apim.isXML(poMediaType)) {
                    result = XML.stringify({omitXmlDeclaration:true},nodelist.item(0));
                  }
                  session.output.write(result);
                } else {
                  // called xslt did not do an apim:output template call, so write the xml output and
                  // set the output media type. If there was input, this should be mediaType otherwise
                  // default to producing application/xml from the policy
                  session.output.write(nodelist);
                  if (input && apim.isXML(mediaType)) {
                    apim.output(mediaType);
                  } else {
                    apim.output('application/xml');
                  }
                }
            } else {
                if (verbose) dbglog.debug(logPrefix + ' transformXSLT: we have NO data');
            }
        }
    });
}
