// ***************************************************** {COPYRIGHT-TOP} ***
//* Licensed Materials - Property of IBM
//* 5725-L30, 5725-Z22, 5725-Z63, 5725-U33
//*
//* (C) Copyright IBM Corporation 2016, 2017
//*
//* US Government Users Restricted Rights - Use, duplication, or
//* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
// ********************************************************** {COPYRIGHT-END}**

exports.Errors = {
  'ConnectionError'       : 'ConnectionError',       // Invoke Policy (urlopen failed, or reading data failed)
  'OperationError'        : 'OperationError',        // Invoke Policy (non-2XX)
  'SOAPError'             : 'SOAPError',             // Invoke Policy (XML Response contains SOAP Fault)
  'MapError'              : 'MapError',              // Map Policy
  'RedactionError'        : 'RedactionError',        // Redaction
  'TransformError'        : 'TransformError',        // XSLT
  'JavaScriptError'       : 'JavaScriptError',       // GatewayScript
  'RuntimeError'          : 'RuntimeError'           // Generic Error
};

// *****************************************************************************************************************
// NOTE: when changing error strings, you'll need to update apimesh/apim-ui/app/apim/assembly/AssemblyInfoController.js
//*****************************************************************************************************************
