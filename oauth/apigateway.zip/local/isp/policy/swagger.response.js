// ***************************************************** {COPYRIGHT-TOP} ***
//* Licensed Materials - Property of IBM
//* 5725-L30, 5725-Z22, 5725-Z63, 5725-U33
//*
//* (C) Copyright IBM Corporation 2016, 2017
//*
//* US Government Users Restricted Rights - Use, duplication, or
//* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
// ********************************************************** {COPYRIGHT-END}**
//
var apim = require('local:///isp/policy/apim.custom.js');
var hm = require('header-metadata');
var verbose = apim.verbose;
var xmlFlowDirection = 'request';

const NoName = undefined;
const SkipExecute = [ 'execute' ];
const MarkerImplFlowStart = {'IMPL-FLOW-STARTS':{}};
const MarkerRespFlowStart = {'RESP-FLOW-STARTS':{}};

// Read the Swagger response into a JavaScript object
session.input.readAsJSON(function(error, swaggerDoc)
{
  if (error)
  {
    apim.console.error("urlopen error: "+JSON.stringify(error));
    throw error;
  }

  // The /v1/catalogs/:catalogId/apis/:apiId does not return the raw Swagger,
  // so we must find it within its response.
  if (swaggerDoc.document) {
    swaggerDoc = swaggerDoc.document;
  }

  // Add data to the input object and write to the ouput context
  //apim.console.debug("SwaggerDoc: " + JSON.stringify(swaggerDoc));
  translateSwaggerToXML(swaggerDoc);

});

// Traverse Swagger Object, building policies.xml as it navigates the tree
function translateSwaggerToXML(swaggerDoc)
{
   var xIbmConfig = swaggerDoc['x-ibm-configuration'];
   var policiesXml = "<policies>\n";
   var operCond = undefined;
   var indent = ' ';
   var theFlow = xIbmConfig.assembly ? xIbmConfig.assembly.execute : undefined;
   var injectToFlow = [];
   var injectIndex = 0;
   var globalHandler = xIbmConfig.assembly ? xIbmConfig.assembly.catch: [];

   // Consolidate the Request, Implementation and Response flows.
   // Temporarily, so we don't break every thing yet, we will support the Beta-like flow,
   // i.e. a single flow (horseshoe) if the swagger we read has it like that. TODO remove before V5 GA.
   //
   // Use a temporary marker to indicate the sub-flows transitions in the flow.
   var marker;
   if (theFlow === undefined)
   {
     var newFlow = [];
     if (xIbmConfig.assembly && xIbmConfig.assembly.request && xIbmConfig.assembly.request.execute)
     {
       newFlow = newFlow.concat(xIbmConfig.assembly.request.execute);
     }
     if (xIbmConfig.assembly && xIbmConfig.assembly.implementation && xIbmConfig.assembly.implementation.execute)
     {
       newFlow = newFlow.concat([MarkerImplFlowStart]).concat(xIbmConfig.assembly.implementation.execute);
     }
     if (xIbmConfig.assembly && xIbmConfig.assembly.response && xIbmConfig.assembly.response.execute)
     {
       newFlow = newFlow.concat([MarkerRespFlowStart]).concat(xIbmConfig.assembly.response.execute);
     }
     theFlow = newFlow;
   }


   // TODO Assembly Context from Swagger

   // CORS Policy
   if (xIbmConfig.cors && xIbmConfig.cors.enabled)
   {
     injectToFlow[injectIndex++] = { "apim.cors": { "title": "CORS" }};
   }

   if (xIbmConfig.oauth2)
   {
     injectToFlow[injectIndex++] = injectOAuthProviderExtension(swaggerDoc);
   }

   //injectToFlow[injectIndex++] = { "foo": { "title": "The Foo Policy", "prop1": "value1", "prop2": "value2" }};

   //@@ SECURITY Policies
   //@@  (a) APP.Identity
   //@@  Basic & OAuth
   //@@  Security may be present at a Global or a local, Path
   //@@  Level, when present at the local level it will override
   //@@  the Global.
   if (swaggerDoc.security && swaggerDoc.security.length == 1)
   {
       // We can insert policy into the flow directly
       var polAgg= [];
       var securityEntry = Object.keys(swaggerDoc.security[0]);
       for (var n=0; n<securityEntry.length; n++)
       {
           var curEntry = securityEntry[n];
           var e = securityProcessor(swaggerDoc.securityDefinitions[curEntry]);
           var p = Object.keys(e);
           var policy = p[0];
           // check for dup apim Identities
           // and merge into a single entry
           if (e[policy].type === "apiKey" && polAgg.length > 0)
           {
               // Loop here and consolidate any apiKey 
               // Client/Secret into a single entry.
               for (var m=0; m<polAgg.length; m++)
               {
                   if (polAgg[m]["apim.appidentity"] && polAgg[m]["apim.appidentity"].requires === "clientID" && e[policy].requires === "clientIDAndSecret")
                    {
                        polAgg[m]["apim.appidentity"].requires = "clientIDAndSecret";
                        break;
                    } 
                    else if (polAgg[m]["apim.appidentity"] && polAgg[m]["apim.appidentity"].requires === "clientIDAndSecret" && e[policy].requires === "clientID")
                    {
                        e[policy].requires = "clientIDAndSecret";
                        polAgg[m]["apim.appidentity"] = e[policy];
                    }
               }
            } 
            else 
            {
                polAgg[polAgg.length] = e;
            }
       }
       injectToFlow = injectToFlow.concat(polAgg);
       injectIndex += polAgg.length;
   }
   else if (swaggerDoc.security && swaggerDoc.security.length > 1)
   {
       var secPolicyArray = [];
       // More than one entry here is an OR scenario
       var securityCount = swaggerDoc.security.length; 

       for (var index=0; index<securityCount; index++)
       {
           var securityEntry = Object.keys(swaggerDoc.security[index]);
           
           // More than one entry in securityKey is the AND scenario
           if (securityEntry.length === 1)
           {   // Single entry
               var e = securityProcessor(swaggerDoc.securityDefinitions[securityEntry]);
               // var p = Object.keys(e);
               // var policy = p[0];
               secPolicyArray[secPolicyArray.length] = e;
           }
           else
           {  
               // create empty object
               var polAggregator = {};
               for (var n=0; n<securityEntry.length; n++)
               {
                   var curEntry = securityEntry[n];
                   var e = securityProcessor(swaggerDoc.securityDefinitions[curEntry]);
                   var p = Object.keys(e);
                   var policy = p[0];
                   // check for dup apim Identities
                   // and merge into a single entry
                   if (e[policy].type === "apiKey" && polAggregator.hasOwnProperty("apim.appidentity"))
                   {
                       // Loop here and consolidate any apiKey 
                       // Client/Secret into a single entry.
                       if (polAggregator["apim.appidentity"].requires === "clientID" && e[policy].requires === "clientIDAndSecret")
                       {
                           polAggregator["apim.appidentity"].requires = "clientIDAndSecret";
                       } 
                       else if (polAggregator["apim.appidentity"].requires === "clientIDAndSecret" && e[policy].requires === "clientID")
                       {
                           e[policy].requires = "clientIDAndSecret";
                           polAggregator["apim.appidentity"] = e[policy];
                       }
                   } 
                   else 
                   {
                       polAggregator[policy] = e[policy];
                   }
               }
               secPolicyArray[secPolicyArray.length] = polAggregator;
           }
       }
       var secPolicy = {"apim.security" : secPolicyArray};
       injectToFlow[injectIndex++] = secPolicy;
   }

   // Add the Rate Limit Action into the flow
   // the params would come from the Product Plans that the API belongs
   // to
   /* if (1) // TODO here we look for rate limits
   {// $plan.ratelimit
     var rateLimitPolicy = { "ratelimit": {
                        "title":    "Plan Limit",
                        "requests": 10,     // TODO, get from plan
                        "scale":    "minute", // TODO, get from plan
                        "period":   5,      // TODO, get from plan
                        "reject":   true,   // TODO, get from plan
                        "shared":   false   // TODO, get from plan
     }};
     injectToFlow[injectIndex++] = rateLimitPolicy;
   }
   */


   // Rebuild the flow:
   // - Take the list of policies injected to the beginning of the array
   theFlow = injectToFlow.concat( theFlow );

   // Assembly Flow - Array
   policiesXml += traverseFlow(theFlow, operCond, indent);

   // Traverse Main Error handler
   if (globalHandler !== undefined)
   {
     policiesXml += traverseCatch(globalHandler, indent);
   }

   policiesXml += '</policies>\n';
   if (verbose) apim.console.debug('XML==\n' + policiesXml);

   hm.current.set('Content-Type', 'application/xml');
   session.output.write(policiesXml);
}

function traverseFlow(flow, operCond, indent)
{
  var xml = "";
  var policyType = Object.keys(flow)[0]; // this is the name of the first property in this object.
  var skipProperties = [];
  //apim.console.debug("traversing..." + indent + policyType);
  //apim.console.debug(flow[policyType]);

  //
  if (flow.constructor === Array)
  {
    for (var i = 0; i < flow.length; i++)
    {
      xml+= traverseFlow(flow[i], operCond, indent);
    }
    return xml;
  }

  // Marks the start of the 'implementation' sub-flow. Currently, not interesting.
  if (MarkerImplFlowStart[policyType] !== undefined) {
    return xml;
  }

  // Marks the start of the 'response' sub-flow.
  if (MarkerRespFlowStart[policyType] !== undefined) {
    xmlFlowDirection = 'response';
    return xml;
  }

  // Language construct - operation-switch.case is an array ...
  //                      operation-switch.case[n].operations == array ...
  //                      operation-switch.case[n].execute    == array ... (see language construct execute)
  //
  // First locate the conditions and iterate over the policies adding the match conditions.
  if (policyType === 'operation-switch')
  {
    for (var i=0; i<flow[policyType].case.length; i++)
    {
      var stCase = flow[policyType].case[i];
      for (var j=0; j<stCase.operations.length; j++)
      {
        var cond = addConditions(stCase.operations[j], indent + ' ');
        xml+= traverseFlow(stCase.execute, cond, indent);
      }
    }
    return xml;
  }

  // Language construct - if
  // - 'skipProperties' indicate the reserved words that must not be considered
  //   a property for a policy and must be, instead, used to traverse a new
  //   subflow. For example, 'execute'.
  if (policyType === 'if')
  {
    skipProperties = [ 'execute' ];
  }

  // This is a typical policyType
  xml = xmlPolicyStart(indent,policyType,flow[policyType].title,xmlFlowDirection);

  if (operCond !== undefined)
  {
    xml+= operCond;
  }

  xml+= addProperties(indent + ' ', NoName, flow[policyType], skipProperties);

  var skippedProperty;
  for (var idx = 0; idx < skipProperties.length; idx++)
  {
    skippedProperty = skipProperties[idx];
    if (verbose) apim.console.debug('newflow' + skippedProperty);
    xml+= traverseFlow(flow[policyType][skippedProperty], operCond, indent + ' ');
  }

  xml+= xmlPolicyEnd(indent);
  return xml;
}

function getPolicyType(name)
{
  switch(name)
  {
  case "set-variable" : return "apim.setvariable";
  case "invoke"       : return "apim.proxy";
  case "xml2json"     : return "apim.xml2json-policy"
  case "json2xml"     : return "apim.json2xml-policy"
  default             : return name;
  }
}


function addConditions(input, indent)
{
  var verb = input.verb.toUpperCase(); ;
  var path = input.path;

  if (path[0] === '/')
  {
    path = path.substring(1);
  }

  path = path.replace(/(\{.*?\})/g,'([^\\/]*)');

  var xml = indent + '<condition>\n';
  xml    += indent + ' <match name="method" type="string">' + verb + '</match>\n';
  xml    += indent + ' <match name="path" type="string">^' + path + '$</match>\n';
  xml    += indent + '</condition>\n';
  return xml;
}


//@@ ==========================================================================
//@@   <policyA>:
//@@      <p1>: [ 'a', 'b', 3 ]
//@@      <p2>: 'value'
//@@      <p3>: {...}
//@@
//@@
//@@     <properties>
//@@       <properties name="p1">
//@@         <property name="0">a</property>
//@@         <property name="1">b</property>
//@@         <property name="2">3</property>
//@@       </properties>
//@@       <property name="p2">value</property>
//@@       <properties name="p3">
//@@       </properties/
//@@     </properties>
//@@
//@@ ==========================================================================
function addProperties(indent, name, input, skipNames)
{
  if (verbose)
  {
    apim.console.debug('\n');
    apim.console.debug('addP: name:' + name + ' type:' + typeof input + ' value:' + JSON.stringify(input));
    apim.console.debug('addP: skip: ' + skipNames);
  }

  var xml = '';

  if (skipNames !== undefined && skipNames.indexOf(name) > -1) {}
  else if (input !== null && typeof input === 'object')
  {
    xml+= xmlPropertiesStart(indent,name,input);
    for (var childName in input)
    {
      if (input.hasOwnProperty(childName)) {
        xml+= addProperties(indent + ' ', childName, input[childName], skipNames);
      }
    }
    xml+= xmlPropertiesEnd(indent);
  }
  else
  {
    xml+= xmlPropertyAdd(indent, name, input);
  }

  return xml;
}



//@@ ==========================================================================
//@@   catch:
//@@     - errors:
//@@         - error1
//@@         - error2
//@@       execute:
//@@         <A FLOW>
//@@     - errors:
//@@         - error3
//@@         - error4
//@@       execute:
//@@         <A FLOW>
//@@     - default
//@@         <A FLOW>
//@@
function traverseCatch(flow, indent)
{
  var xml = '';
  var operCond = undefined;
  // the flow is an array of "errors" and "default"
  if (flow.constructor !== Array)
  {
    apim.console.error('traverse catch: not an array');
    apim.console.error(flow);
    return '';
  }

  var key;
  for (var i = 0; i < flow.length; i++)
  {
    key = Object.keys(flow[i])[0];
    xml+= xmlPolicyStart(indent,'catch');
    if (key === 'errors')
    {
      xml+= addProperties(indent + ' ', NoName, flow[i], SkipExecute);

      if (flow[i].execute !== undefined)
      {
        xml+= traverseFlow(flow[i].execute, operCond, indent + ' ');
      }
    }
    else
    {
      xml+= traverseFlow(flow[i][key], operCond, indent + ' ');
    }
    xml+= xmlPolicyEnd(indent);
  }
  return xml;
}

//@@ ===================================================
//@@ Inject the OAuth2 Provider Policy into the Flow
//@@ ===================================================
// todo : this does not even make sense for the response flow
function injectOAuthProviderExtension(swaggerDoc)
{
  var xIbmConfig = swaggerDoc['x-ibm-configuration'];

  var oauth2server = {
    "client-type" : xIbmConfig.oauth2['client-type'],
    "grants" : xIbmConfig.oauth2.grants.join("+"),
    "identity-extraction.type": xIbmConfig.oauth2['identity-extraction'].type,
    "authorization.type": xIbmConfig.oauth2.authorization.type
  }

  for (var scope in xIbmConfig.oauth2.scopes)
  {
    if (xIbmConfig.oauth2.scopes.hasOwnProperty(scope)) {
      var name = 'scopes.' + scope;
      oauth2server[name] = xIbmConfig.oauth2.scopes[scope];
    }
  }
  // this does not make sense for client_credential/application grant type
  if (!(xIbmConfig.oauth2.grants.length === 1 &&
        xIbmConfig.oauth2.grants.indexOf('application') > -1)) {
    if (xIbmConfig.oauth2.authentication.file !== undefined) {
      oauth2server.type = 'file';
    }
  }

  oauth2server['access-token.ttl'] = 3600;
  if (xIbmConfig.oauth2['access-token'] && xIbmConfig.oauth2['access-token'].ttl !== undefined) {
    oauth2server['access-token.ttl'] = xIbmConfig.oauth2['access-token'].ttl;
  }

  if (xIbmConfig.oauth2['refresh-token'] && xIbmConfig.oauth2['refresh-token'].count !== undefined) {
    oauth2server['refresh-token.count'] = xIbmConfig.oauth2['refresh-token'].count;
    if (oauth2server['refresh-token.count'] > 0) {
      oauth2server['refresh-token.ttl'] = 2682000;
      if (xIbmConfig.oauth2['refresh-token'].ttl !== undefined)
        oauth2server['refresh-token.ttl'] = xIbmConfig.oauth2['refresh-token'].ttl;
    }
  }

  if (xIbmConfig.oauth2['revocation']) {
    if (xIbmConfig.oauth2['revocation'].url !== undefined) {
      oauth2server['revocation.url'] = xIbmConfig.oauth2['revocation'].url
    }
  }

  var operations = [];
  var operationsIdx = 0;
  for (var path in swaggerDoc.paths) {
    if (swaggerDoc.paths.hasOwnProperty(path)) {

      for (var verb in swaggerDoc.paths[path]) {
        if (swaggerDoc.paths[path].hasOwnProperty(verb)) {
          operations[operationsIdx++] = { "path": path, "verb": verb };
        }
      }

    }
  }
  var policy = { "oauth2-server" : oauth2server };
  var opSwitch = {
    "operation-switch" : {
      "case" : [ { "operations" : operations, "execute": [policy] } ]
    }
  }
  return opSwitch;
}

//@@ ==========================================================================
//@@
//@@ Utility functions to create XML strings (elements, attributes, etc)
//@@
//@@ ==========================================================================


//@@ <policy> element
//@@   attributes:
//@@     - @type       - the policy type, CORS, Validate, Proxy, etc.
//@@     - @name       - title provided in Swagger (optional)
//@@     - @direction  - request | response
//@@     - @depth      - indicates the scope of this policy, parent/@depth+1
var policyDepth = 0;
function xmlPolicyStart(indent,type,name,direction)
{
  policyDepth++;
  var xml = indent + '<policy type="' + getPolicyType(type) + '"';
  xml+= ' name="' + (name===undefined?type:name) + '"';
  xml+= ' direction="' + (direction===undefined?'request':direction) + '"';
  return xml + ' depth="' + policyDepth + '">\n';
}
function xmlPolicyEnd(indent)
{
  policyDepth--;
  return indent + '</policy>\n';
}


//@@ <properties> element
//@@   attributes:
//@@     - @name       - name as in swagger (optional)
//@@     - @array      - true if this represents an array (optional, omitted indicates false)
function xmlPropertiesStart(indent,name,input)
{
  var attrName = '';
  var attrArray = '';
  if (name !== undefined)
  {
    attrName = ' name="' + name + '"';
  }
  if (input.constructor === Array)
  {
    attrArray = ' array="true"';
  }
  return indent + '<properties' + attrName + attrArray + '>\n';
}
function xmlPropertiesEnd(indent)
{
  return indent + '</properties>\n';
}

//@@ <property> element
//@@   attributes:
//@@     - @name       - name as in swagger or index if indicates an array element
function xmlPropertyAdd(indent,name,value)
{
  var additionalProperties = '';
  if (value === null)
  {
    additionalProperties = ' type="null"';
    value = '';
  }
  else
  {
    additionalProperties = ' type="' + typeof value + '"';
  }

  if (typeof value === 'string' && value.indexOf('&') > -1)
  {
    value = '<![CDATA[' + value + ']]>'
  }
  return indent + '<property name="' + name + '"' + additionalProperties + '>' + value + '</property>\n';
}

function securityProcessor(sec)
{
    if (sec.type == "apiKey")
    {   // (a) APP.identity
        // valid secret query name values: appSecret, client_secret
        // valid secret header name values: X-IBM-Client-Secret
        // valid client ID query name values: appID, client_id
        // valid client ID header name values: X-IBM-Client-Id
        var nameAttr = sec.name;
        if (nameAttr === "appID" || nameAttr === "client_id" || nameAttr === "X-IBM-Client-Id")
        {
            var securityPolicy = genAPIMIdentity("clientID", sec.in, sec.type, sec.name);
            return securityPolicy;
        }
        else if(nameAttr === "appSecret" || nameAttr === "client_secret" || nameAttr === "X-IBM-Client-Secret")
        {
            var securityPolicy = genAPIMIdentity("clientIDAndSecret", sec.in, sec.type, sec.name);
            return securityPolicy;
        }
    } 
    else if (sec.type === "basic") 
    {
        // Basic Auth
        // (a) URL
        // (b) SSL Profile
        if (sec["x-ibm-authentication-url"])
        {   // (a) URL
            var basicAuthPolicy = genAPIMBasicAuthURL(sec["x-ibm-authentication-url"].url, sec["x-ibm-authentication-url"]["tls-profile"]);
            return basicAuthPolicy;
        }
    } // LDAP or Registry
    // Not a known or supported type.
    return {};
}

//@@ Funtion to generate the apim.identity policy
//@@
function genAPIMIdentity(req_str, in_str, type_str, name_str)
{
    var apimId = {"apim.appidentity" : {
            "title": "security-appID",
            "requires": req_str,
            "in": in_str,
            "type": type_str,
            "name": name_str
           }};
    return apimId;
}

//@@ function to generate apim.basicauth url policy
//@@ 
function genAPIMBasicAuthURL(url_str, url_tls)
{
    var basicAuthURL = { "apim.basicauth": {
            "title" : "security-basic-auth-url",
            "type" : "authUrl",
            "authenticationURL" : url_str,
            "authenticationURLsslProfile" : (typeof(url_tls) === 'undefined' ? '' : url_tls)
           }};
    return basicAuthURL;
}
