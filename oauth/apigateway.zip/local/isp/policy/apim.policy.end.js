// ***************************************************** {COPYRIGHT-TOP} ***
//* Licensed Materials - Property of IBM
//* 5725-L30, 5725-Z22, 5725-Z63, 5725-U33
//*
//* (C) Copyright IBM Corporation 2016, 2017
//*
//* US Government Users Restricted Rights - Use, duplication, or
//* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
// ********************************************************** {COPYRIGHT-END}**

var apim = require('local:///isp/policy/apim.custom.js');
var svcmeta = require ('service-metadata');
var headermeta = require('header-metadata');
var direction = svcmeta.getVar('var://service/transaction-rule-type');
var _apimgmt = session.name('_apimgmt');
var logprefix = 'apim.policy.end';
var errors = require('local:///isp/policy/apim.exception.js');
var verbose = apim.verbose;

//@@ TEST CODE
//@@ var skipBackside3 = svcmeta.list().filter(function(elm) {
//@@   return elm.name === 'var://service/mpgw/skip-backside';
//@@ });
//@@ apim.console.debug('skip3 ' + JSON.stringify(skipBackside3));

//@@ get skipBackside value
//@@ skipBackside1(DP7.5) and skipBackside2(ourownvar)
var skipBackside1 = svcmeta.getVar('var://service/mpgw/skip-backside');
var skipBackside2 = _apimgmt.getVariable('skip-backside');
if (verbose) apim.console.debug('apim.policy.end: skip: ' + skipBackside1 + ' ' + skipBackside2);

//@@ if there is no proxy in the flow, save the current headers and
//@@ restore them when we start the response multistep flow
//@@ this is necessary as the built-in echo service does not replay
//@@ the headers and even if it did, it would likely change or
//@@ inject new ones
if (direction === 'request') {
  var routingUrl = svcmeta.routingUrl;
  var internalEcho = _apimgmt.getVariable('internal-mpgw-url');
  if (routingUrl && routingUrl.indexOf(internalEcho) === 0) {
    var headersToSave = {};
    for (var hdr in headermeta.current.headers) {
      if (headermeta.current.headers.hasOwnProperty(hdr) && (hdr.toLowerCase() !== 'content-type')) {
        headersToSave[hdr] = headermeta.current.headers[hdr];
      }
    }
    _apimgmt.setVariable('headers-saved', headersToSave);
  }
}

//@@ TODO Attempt to reset "SkipBackside" (available in DP 7.5)
if (skipBackside1 || skipBackside2 || direction === 'response')
{
  var policySession = session.name('policy');
  var exception = policySession.getVariable('flow/exception');
  if (verbose) apim.console.debug(logprefix + ': ' + JSON.stringify(exception));
  if (exception)
  {
    if (verbose) apim.console.debug(logprefix + ': rejecting with ' + exception.message);
    var apiSession = session.name('api');
    if (apiSession !== undefined) {
      apiSession.setVar('error-protocol-response', exception.httpCode);
      apiSession.setVar('error-protocol-reason-phrase', exception.httpReasonPhrase);
      apiSession.setVar('error-name', exception.name);
      apiSession.setVar('error-message', exception.message);
    }
    policySession.setVar('flow/exception-uncaught',true);

    if (exception.name == errors.Errors.SOAPError) {
      //special handling for SOAPError
      _apimgmt.setVar('use-policy-output','true');
      _apimgmt.setVar('policy-output-mediaType', 'application/xml');
      getPolicyOutput().write(exception.message);
    }
    else {
      session.reject(exception.message);
    }
  }
}
else
{
  if (verbose) apim.console.debug(logprefix);
}


function getPolicyOutput() {
  var out = session.name('policy-output');
  if (!out) {
    out = session.createContext('policy-output');
  }
  return out;
}
