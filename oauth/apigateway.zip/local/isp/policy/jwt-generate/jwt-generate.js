/**
 * Licensed Materials - Property of IBM
 * 5725-L30, 5725-Z22, 5725-Z63, 5725-U33

 * Copyright IBM Corporation 2016, 2017

 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/**
 * @brief Will generate a JSON Web Token and assign the generated JWT to the
 *        specified variable
 *        @param jwt String: variable to assign JWT to
 *                default: generated.jwt
 *        @param jti-claim: boolean true|false
 *               If true generateUUID() called and assigned to jti claim value
 *        @parm iss-claim  String: The issuer claim value
 *                default: idg
 *        @parm exp-claim Integer: The validity period(in seconds) for
 *                                  calculating the exp claim
 *        @parm aud-claim  String: The Audience claim value
 *        @parm custom-claims Strig: variable name from which a JSON object
 *                                   of custom claims can be found
 * For jwt-generate 1.0.0
 *        @parm jws-crypto String: Crypto object to sign JWT
 *        @parm jws-jwk String: Variable name within which a jwk to sign the
 *                              JWT can be found
 *        @parm jwe-crypto String: Crypto object to encrypt JWT
 *        @parm jwe-jwk String: Variable name within which a jwk to encrypt the
 *                              JWT can be found
 * For jwt-generate 1.0.1
 *        @parm jws-obj String: Type/name:version of managed object to use for sign JWT
 *                              example: private-key/my-key:1.0.0
 *        @parm jwe-obj String: Type/name:version of managed object to use for encrypt JWT
 *                              example: public-key/my-cert:1.0.0
 */

var jwt = require('jwt'),
  jose = require('jose'),
  apic = require('local:///isp/policy/apim.custom.js'),
  util = require('util'),
  dbglog = apic.console,
  verbose = apic.verbose;

var logPrefix = 'jwt-generate: ';
var policyProperties = apic.getPolicyProperty();

try {
  if (verbose) {
    dbglog.debug(logPrefix + "Policy properties [" + JSON.stringify(policyProperties) + "]");
  }

  var claims = {};
  var currentDT = Math.floor(new Date() / 1000);

  if (policyProperties['jti-claim'] &&
    policyProperties['jti-claim'] === true)
    claims['jti'] = session.generateUUID();

  if (policyProperties['iss-claim'])
    claims['iss'] = apic.getvariable(policyProperties['iss-claim']);

  if (policyProperties['sub-claim'])
    claims['sub'] = apic.getvariable(policyProperties['sub-claim']);

  if (policyProperties['aud-claim']) {
    var audArrayOrString = apic.getvariable(policyProperties['aud-claim']);
    if (audArrayOrString.indexOf(",") === -1)
      claims['aud'] = audArrayOrString;
    else
      claims['aud'] = audArrayOrString.split(",");
  }

  if (policyProperties['exp-claim']) {
    var expClaimValue = policyProperties['exp-claim'];
    if (util.safeTypeOf(expClaimValue) === 'string')
      expClaimValue = parseInt(expClaimValue);
    claims['exp'] = currentDT + expClaimValue;
  }

  claims['iat'] = currentDT;

  if (policyProperties['private-claims']) {
    var jsonString = apic.getvariable(policyProperties['private-claims']);
    try {
      // Verify that the custom claims is valid JSON structure,
      //  [todo] this does not look right, it is a waste of CPU cycle.
      //  JSON parse will fail, if it is not a valid object
      var claimJSON = JSON.parse(jsonString);
      for (var claim in claimJSON) {
        claims[claim] = claimJSON[claim];
      }
    } catch (e) {
      throw (e + ' Error -- Private Claims are not in JSON format');
    }
  }

  var encoder = new jwt.Encoder(claims);

  if (policyProperties['jws-obj']) {

    var isJWK = getMOProperty('jws-obj', 'isJWK');
    var jwsObj;
    if (isJWK) {
      jwsObj = JSON.parse(getMOFileContents('jws-obj').toString());
    } else {
      jwsObj = getMONameDP('jws-obj');
    }

    var jwsHeader = jose.createJWSHeader(jwsObj, policyProperties['jws-alg']);
    encoder.addOperation('sign', jwsHeader)

  } else if (policyProperties['jws-crypto']) {
    var jwsHeader = jose.createJWSHeader(policyProperties['jws-crypto'], policyProperties['jws-alg']);
    encoder.addOperation('sign', jwsHeader)
  } else {
    if (policyProperties['jws-jwk']) {
      var jsonString = apic.getvariable(policyProperties['jws-jwk']);
      try {
        var jwsJWK = JSON.parse(jsonString);
        var jwsHeader = jose.createJWSHeader(jwsJWK, policyProperties['jws-alg']);
        encoder.addOperation('sign', jwsHeader);
      } catch (e) {
        throw (e + ' Error -- JWK is not in valid JSON format');
      }
    }
  }

  if (policyProperties['jwe-obj']) {
    var isJWK = getMOProperty('jwe-obj', 'isJWK');
    var jweObj;
    if (isJWK) {
      jweObj = JSON.parse(getMOFileContents('jwe-obj').toString());
    } else {
      jweObj = getMONameDP('jwe-obj');
    }

    var jweHeader = jose.createJWEHeader(policyProperties['jwe-enc'])
      .setProtected('alg', policyProperties['jwe-alg'])
      .setKey(jweObj);
    if (policyProperties['jws-obj'])
      jweHeader.setProtected('cty', 'JWT');
    encoder.addOperation('encrypt', jweHeader)
  } else if (policyProperties['jwe-crypto']) {
    var jweHeader = jose.createJWEHeader(policyProperties['jwe-enc'])
      .setProtected('alg', policyProperties['jwe-alg'])
      .setKey(policyProperties['jwe-crypto']);
    if (policyProperties['jws-crypto'] ||
      policyProperties['jws-jwk'])
      jweHeader.setProtected('cty', 'JWT');
    encoder.addOperation('encrypt', jweHeader)
  } else {
    if (policyProperties['jwe-jwk']) {
      var jsonString = apic.getvariable(policyProperties['jwe-jwk']);
      try {
        var jweJWK = JSON.parse(jsonString);
        var jweHeader = jose.createJWEHeader(policyProperties['jwe-enc'])
          .setProtected('alg', policyProperties['jwe-alg'])
          .setKey(jweJWK);
        if (policyProperties['jws-crypto'] ||
          policyProperties['jws-jwk'])
          jweHeader.setProtected('cty', 'JWT');
        encoder.addOperation('encrypt', jweHeader)
      } catch (e) {
        throw (e + ' Error -- JWK is not in valid JSON format');
      }
    }
  }

  var theJWT = new Promise(function(resolve, reject) {
    encoder.encode(function(error, aJWT) {
      if (error) {
        reject(error);
      } else {
        if (verbose) {
          dbglog.debug(logPrefix + "JWT Generated: " + aJWT);
        }
        resolve(aJWT);
      }
    });
  });

  theJWT.then(function(result) {
      // write the JWT token string to the named context
      if ((policyProperties['jwt']) && (policyProperties['jwt'] !== ''))
        apic.setvariable(policyProperties['jwt'], result, 'set');
      else {
        //by default Set the JWT token in the HTTP Authorization header as a bearer token
        var jwtBearerToken = 'Bearer ' + result;
        var headers = require('header-metadata');
        headers.response.set('Authorization', jwtBearerToken);
        headers.current.set('Authorization', jwtBearerToken);
        if (verbose) {
          var authHdr = headers.current.get('Authorization');
          dbglog.debug(logPrefix + "AuthHeader: " + authHdr);
        }
      }
    })
    .catch(function(error) {
      if (error.message) {
        console.error(logPrefix + ":" + error.message);
        session.reject(error.message);
      } else {
        console.error(logPrefix + ":" + error);
        session.reject(error);
      }
    });

} catch (error) {
  if (error.message) {
    console.error(logPrefix + ":" + error.message);
    session.reject(error.message);
  } else {
    console.error(logPrefix + ":" + error);
    session.reject(error);
  }
  return;
}

// Get the file contents of a managed object
function getMOFileContents(propName) {

  var moName = policyProperties[propName];
  var moTokens;
  try {
    moTokens = moName.split('/');
  } catch (err) {
    console.info("managed-object: type parse error");
    throw (e + ' Error -- managed-object: type parse error');
  }

  return new Buffer(apic.getManagedObjectValue(moTokens[0], moTokens[1], 'file'), 'base64');
}

// Get the file contents of a managed object
function getMOProperty(policyPropName, moPropName) {

  var moName = policyProperties[policyPropName];
  var moTokens;
  try {
    moTokens = moName.split('/');
  } catch (err) {
    console.info("managed-object: type parse error");
    throw (e + ' Error -- managed-object: type parse error');
  }

  var options = {
    name: moTokens[1],
    property: moPropName
  };
  return apic.getManagedObjectValue(moTokens[0], moTokens[1], moPropName);
}


// Get the file contents of a managed object
function getMONameDP(propName) {

  var moName = policyProperties[propName];
  var moTokens;
  try {
    moTokens = moName.split('/');
  } catch (err) {
    console.info("managed-object: type parse error");
    throw (e + ' Error -- managed-object: type parse error');
  }

  return apic.getManagedObjectDPName(moTokens[0], moTokens[1]);
}
