// ***************************************************** {COPYRIGHT-TOP} ***
// Licensed Materials - Property of IBM
// 5725-L30, 5725-Z22, 5725-Z63, 5725-U33
//
// (C) Copyright IBM Corporation 2016, 2017
//
// US Government Users Restricted Rights - Use, duplication, or
// disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
// ********************************************************** {COPYRIGHT-END}**

var apim = require('local:///isp/policy/apim.custom.js');
var transform = require('transform');
var err = require('local:///isp/policy/apim.exception.js');

var dbglog = apim.console;
var verbose = apim.verbose;
var logPrefix = 'apim.redact.js: ';

//@@ MAIN
var payload;
var direction = session.parameters.direction; //@@ Direction: request | response | logs

// Determines if we should try to redact the input as well or only set the variable needed for redacting from the logs
var redactInput = session.parameters.redactInput; // true | false (as strings)

if (!direction) {
    apim.error(err.Errors.RedactionError, 500, 'Internal Server Error', 'Missing parameter direction');
    return;
}

if (direction == 'request') {
  var redactLog = session.name('_apimgmt').getVar('redactFromLog');
  if (redactLog === undefined) {
    redactLog = [];
  }
  redactLog.push(apim.getPolicyProperty());
  session.name('_apimgmt').setVar('redactFromLog', redactLog);
}

if (redactInput == 'false') {
  // This is not an error - no further actions required
  return;
}

//@@ Read input provided by calling XSLT. It is never empty, it is always a DOM NodeList
session.input.readAsXML(function(error, xmlNode) {
  if (error) {
    apim.error(err.Errors.RedactionError, 500, 'Internal Server Error', 'Error attempting to read the input data');
    return;
  }
  if (verbose) {
    apim.console.debug(logPrefix + 'direction: ' + direction);
    apim.console.debug(logPrefix + 'payload type: ' + typeof xmlNode);
    apim.console.debug(XML.stringify(xmlNode));
  }
  //redactPayload(direction);
  readInputCallback(xmlNode);
});


function readInputCallback(data) {
  var xslt;
  var policyProps = [];
  if (direction == 'response' || direction == 'request') {
    policyProps[0] = apim.getPolicyProperty();
    xslt = generateRedactXSLT(policyProps, direction);
  }
  else if (direction == 'logs') {
    var redactLog = session.name('_apimgmt').getVar('redactFromLog');
    xslt = generateRedactXSLT(redactLog, direction);
  }
  if (data !== undefined) {
    if (verbose) {
      apim.console.debug(logPrefix + "readInputCallback: data2: " + data);
    }
    var redactxslt = session.name('redactxslt') || session.createContext('redactxslt');
    redactxslt.write(xslt);
    redact(data);
  }
}

function generateRedactXSLT(policyPropsArray, actionType) {
  var xslt;
  var xsltHeader;
  var xsltFooter;
  xsltHeader  = '<?xml version="1.0" encoding="UTF-8"?>\n'
  xsltHeader += '<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:dp="http://www.datapower.com/extensions" version="1.0">\n';
  xsltHeader += ' <xsl:variable name="obfuscate">*******</xsl:variable>\n';

  // This must match the jsonx:number checks in json_suffix.xsl for analytics
  xsltHeader += ' <xsl:variable name="obfuscateNum">"*******"</xsl:variable>\n';

  xsltHeader += ' <xsl:template match="/|@*|node()">\n';
  xsltHeader += '  <xsl:copy><xsl:apply-templates select="@*|node()"/></xsl:copy>\n';
  xsltHeader += ' </xsl:template>\n';
  xsltFooter  = '</xsl:stylesheet>\n';

  if (verbose) {
    apim.console.debug(logPrefix + "generateRedactXSLT: policyPropsArray " + JSON.stringify(policyPropsArray));
    apim.console.debug(logPrefix + "generateRedactXSLT: actionType       " + actionType);
  }

  xslt = xsltHeader;

  for (var int = 0; int < policyPropsArray.length; int++) {
    var policyProps = policyPropsArray[int];
    var actions = policyProps.actions;

    if (actions !== undefined) {
      for (var action_count = 0; action_count < actions.length; action_count++) {
        var actionItem = actions[action_count];
        if (actionItem !== undefined) {
          var from = actionItem.from;
          if (from.indexOf(actionType) >= 0 || from.indexOf('all') >= 0) {
            var redactAction = actionItem.action;
            var path = actionItem.path;
            if (redactAction !== undefined) {
              if (redactAction.toLowerCase() == 'redact') {
                xslt += ' <xsl:template match="' + path + '/text()">';
                xslt += '<xsl:choose><xsl:when test="name(..)=\'jsonx:number\' or name(..)=\'json:number\'">';
                xslt += '<xsl:value-of select="$obfuscateNum"/>';
                xslt += '</xsl:when><xsl:otherwise>';
                xslt += '<xsl:value-of select="$obfuscate"/>';
                xslt += '</xsl:otherwise></xsl:choose>';
                xslt += '</xsl:template>\n';
              }
              else if (redactAction.toLowerCase() == 'remove') {
                xslt += ' <xsl:template match="' + path + '"/>\n';
              }
              else {
                // we have a redact action we dont recognise - log error
                apim.console.error(logPrefix + 'generateRedactXSLT: We have received a redaction action that is not supported [' + redactAction + ']');
              }
            }
            else {
              apim.console.error(logPrefix + 'generateRedactXSLT: We have received a redaction action that is not supported [' + redactAction + ']');
            }
          }
        }
      }
    }
  }
  xslt += xsltFooter;
  if (verbose) {
    apim.console.debug(logPrefix + "generateRedactXSLT: generated xslt\n" + xslt);
  }
  return xslt;
}

function redact(xmldata, xslt_location) {
    var xsltOption = {
            'location': (xslt_location===undefined ? 'var://context/redactxslt' : xslt_location),
            'honorAbort': true
    };

    if (xmldata!==undefined) {
        var xmlNode = xmldata;
        xsltOption.xmldom = xmlNode;
    }

    // start the xslt execution with the xsltOption
    transform.xslt(xsltOption, function(error, nodelist, isAbort) {
        if (error) {
            apim.error(err.Errors.RedactionError, 500, 'Internal error', JSON.stringify(error));
        } else {
            // if xslt execution was success, the transformation result will be
            // put into the nodelist (a DOM NodeList structure)
            if (nodelist && nodelist.length > 0) {
                if (verbose) {
                    dbglog.debug(logPrefix + 'redact: we have data ['+XML.stringify(nodelist)+']');
                }
                session.output.write(nodelist);
            } else {
                if (verbose) dbglog.debug(logPrefix + 'redact: we have NO data');
            }
        }
    });
}
