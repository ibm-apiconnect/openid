// ***************************************************** {COPYRIGHT-TOP} ***
//* Licensed Materials - Property of IBM
//* 5725-L30, 5725-Z22, 5725-Z63, 5725-U33
//*
//* (C) Copyright IBM Corporation 2014, 2017
//*
//* US Government Users Restricted Rights - Use, duplication, or
//* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
// ********************************************************** {COPYRIGHT-END}**
//
var apim = require('local:///isp/policy/apim.custom.js');
var dbglog = apim.console;
var verbose = apim.verbose;

var STATIC_CONTEXT = "_static_";

var policyProperties = apim.getPolicyProperty();

if (verbose){
  dbglog.debug("apim.setvariable.js -> "+JSON.stringify(policyProperties));
}

if (policyProperties.actions){
  policyProperties.actions.forEach(function(actionObj){
    if (verbose){
      dbglog.debug("policyProperties.actions -> "+ JSON.stringify(actionObj));
    }

    var action;
    var varName;
    var varValue;

    for( var key in actionObj ) {
      if (actionObj.hasOwnProperty(key)) {
        if (key === 'set' || key === 'add' ||key === 'clear'){
            action = key;
            break;
        }
      }
    }
   
    if (action === undefined || action.length === 0){
        dbglog.error("SetVariable:Unknown Action ->["+action+"] ... Skipping");
    }
    else {
      varName = actionObj[action];
      varValue = actionObj['value']; //processReplacements( actionObj['value'] );

      if (verbose){
        dbglog.debug("apim.setvariable.js action -> [" + action + "]");
        dbglog.debug("apim.setvariable.js var -> [" + varName + "]");
        dbglog.debug("apim.setvariable.js value -> [" + varValue + "]");
      }
      apim.setvariable(varName, varValue, action );
    }

  });
} else {
  dbglog.error("SetVariable: No actions found ... Doing nothing.");
}
