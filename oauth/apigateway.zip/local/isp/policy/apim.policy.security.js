// ***************************************************** {COPYRIGHT-TOP} ***
//* Licensed Materials - Property of IBM
//* 5725-L30, 5725-Z22, 5725-Z63, 5725-U33
//*
//* (C) Copyright IBM Corporation 2016, 2017
//*
//* US Government Users Restricted Rights - Use, duplication, or
//* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
// ********************************************************** {COPYRIGHT-END}**
//


//@@ main()
var dbglog = console.options({'category':'apiconnect'});
var apim = require('local:///isp/policy/apim.custom.js');
var sm = require('service-metadata');
var multistep = require('multistep');
var verbose = apim.verbose;
var policy_debug =  session.name('_apimgmt').getVar('policy/debug');

if (policy_debug) {
    apim.console.debug("security policy:policy debug is set to ["+policy_debug+"]");
}

var policyProperties = apim.getPolicyProperty();
if (policy_debug) {
    dbglog.debug("proxy policy:Policy properties ["+JSON.stringify(policyProperties)+"]");
}

var indexOr = 0;
var indexAnd = 0;

startORProcessing();

//@@ Function to start looking at the next OR block
//@@ This assumes none of the previous OR sections have succeeded.
function startORProcessing() {
    if (indexOr >= policyProperties.length)
    {
        //@@ We went thru all the policies, none succeeded.
        endWithError();
    } else {
        //@@proceed to the next policy
        //@@ clear any previous errors
        session.name('policy').deleteVariable('flow/exception');
        session.name('api').deleteVariable('error-name');
        session.name('api').deleteVariable('error-message');
        session.name('api').deleteVariable('error-protocol-reason-phrase');
        session.name('api').deleteVariable('error-protocol-response');
        session.name('api').deleteVariable('ignore-catch');
        sm.errorProtocolResponse = '';
        sm.errorProtocolReasonPhrase = '';
        indexAnd = 0;
        processPolicy();
    }
}

function processPolicy()
{
    //@ the index for Or and And are the current policy to try to run.
    var policySet = Object.keys(policyProperties[indexOr]);
    var policyToProcess = policySet[indexAnd];
    if (policyToProcess === "apim.appidentity") {
        var object = policyProperties[indexOr][policyToProcess];
        var xml = GenerateXML("apim.appidentity", "apim-security-appid", object);
        var polXML = XML.parse(xml);

        session.name('policy').setVar('fw/current-policyXML', polXML);
        runappidentity();
    } else if (policyToProcess === "apim.basicauth") {
        var object = policyProperties[indexOr][policyToProcess];
        var xml = GenerateXML("apim.basicauth", "apim-security-basic", object);
        var polXML = XML.parse(xml);

        session.name('policy').setVar('fw/current-policyXML', polXML);
        runbasicAuth();
    } else if (policyToProcess === "oauth2-validate") {
        var object = policyProperties[indexOr][policyToProcess];
        var introspectUrl = object['introspection-url'] || '';
        if (introspectUrl != '') {
            object['introspection-url'] = encodeURIComponent(introspectUrl);
        }
        var xml = GenerateXML("oauth2-validate", "oauth2-validate-security", object);
        var polXML = XML.parse(xml);

        session.name('policy').setVar('fw/current-policyXML', polXML);
        runoauth2();
    }
    else if (policyToProcess === "oauth2-validate-mfp") {
        var object = policyProperties[indexOr][policyToProcess];
        var xml = GenerateXML("oauth2-validate-mfp", "oauth2-validate-security-mfp", object);
        var polXML = XML.parse(xml);
        
        // used by mfp-filter-v8.js
        var mfpOrSecDefFlowCtx = session.name('mfpOrSecDefFlowCtx') || session.createContext('mfpOrSecDefFlowCtx');
        mfpOrSecDefFlowCtx.setVar('mfpOrSecDefCurrentPolicy', object);
        
        session.name('policy').setVar('fw/current-policyXML', polXML);
        runoauth2MFP();
    }
}

function endWithError() {
  var apiSession = session.name('api');

  if (verbose) {
    dbglog.debug('policy.security.js: exception-uncaught: ' + session.name('policy').getVar('flow/exception-uncaught'));
    dbglog.debug('endWithError: ' + apiSession.getVar('error-protocol-response'));
    dbglog.debug('endWithError: ' + apiSession.getVar('error-protocol-reason-phrase'));
    dbglog.debug('endWithError: ' + apiSession.getVar('error-message'));
  }

  var ignorecatch = apiSession.getVar('ignore-catch');
  if (ignorecatch === undefined) {
    ignorecatch = 'true';
  }

  var httpCode = apiSession.getVar('error-protocol-response');
  if (httpCode === undefined || httpCode.length === 0) {
    var servicemeta = require('service-metadata');
    var svcErrorSubcode = servicemeta.errorSubcode;
    if (verbose) {
      apim.console.debug('endWithError: SUBC ' + svcErrorSubcode);
    }
    // error could be buried in service variables
    // if this was an AAA failure
    if (svcErrorSubcode === '0x01d30001') { // AAA Authentication Failure
      var httpCode = '401';
      var httpReason = 'Unauthorized';
      var errorName = 'Authentication Failure';
      var errMessage = 'This server could not verify that you are authorized to access the URL';
    } else {
      httpCode = '500';
    }
    apim.error(errName, httpCode, httpReason, errMessage, ignorecatch);
    return;
  }

  var httpReason = apiSession.getVar('error-protocol-reason-phrase');
  if (httpReason === undefined || httpReason.length === 0) {
    httpReason = 'Internal Server Error';
  }
  var errName = apiSession.getVar('error-name');
  if (errName === undefined || errName.length === 0) {
    errName = require('local:///isp/policy/apim.exception.js').Errors.RuntimeError;
  }
  var errMessage = apiSession.getVar('error-message');
  if (errMessage == undefined || errMessage.length == 0) {
    errMessage = 'Security Failed or not registered to a plan.';
  }

  apim.error(errName, httpCode, httpReason, errMessage, ignorecatch);

}

function runappidentity(){
    //@@ Run the xform ourselves
    var transform = require('transform');
    var options = {"location" : "local:///isp/policy/apim.appidentity.xsl",
                  "honorAbort" : false};
    transform.xslt(options, appidentityCallback);
}

function appidentityCallback(err, nodelist, abortInfo)
{
    if (err)
    {
        if (verbose) dbglog.debug("App Identity failed.");
        //@@ No need to continue checking, move to next OR case.
        indexOr++;
        startORProcessing();
    }
    else
    {
      indexAnd++;
      var policySet = Object.keys(policyProperties[indexOr]);
      if (indexAnd >= policySet.length) {
        //@@ We went thru all the policies, and all succeeded.
        //@@ Success
        if (verbose) dbglog.debug("App Identity succeeded. Security Passed.");

        //@@ Reset any previous failure
        session.name('policy').setVariable('fw/next-policy', '_DEFAULT_');
        session.name('policy').deleteVariable('flow/exception');
        session.name('api').deleteVariable('error-name');
        session.name('api').deleteVariable('error-message');
        session.name('api').deleteVariable('error-protocol-reason-phrase');
        session.name('api').deleteVariable('error-protocol-response');
        session.name('_apimgmt').deleteVariable('error/www-authenticate');
        sm.errorProtocolResponse = '';
        sm.errorProtocolReasonPhrase = '';
      } else {
        //@@ Process the next policy
        if (verbose) dbglog.debug("App Identity succeeded. Looking for additional policy to process.");
        processPolicy();
      }
    }
}

function runoauth2()
{
    //@@ Run the rule ourselves.
    //@@ Call rull for doing oauth validate
    multistep.callRule("webapi-policy-oauth-1", session.input, session.output, oAuthCallback);
}

function runoauth2MFP()
{
    //@@ Run the rule ourselves.
    //@@ Call rull for doing oauth validate
    multistep.callRule("webapi-policy-oauth-1-mfp", session.input, session.output, oAuthCallback);
}

function oAuthCallback(err)
{
    if (err) {
        if (verbose) dbglog.debug("OAuth Identity failed.");
        //@@ Mark the current AND as false, and move on to the next policy
        indexOr++;
        startORProcessing();
    }
    else
    {
        indexAnd++;
        var policySet = Object.keys(policyProperties[indexOr]);
        if (indexAnd >= policySet.length) {
            //@@ We went thru all the policies, and all succeeded.
            //@@ Success
            if (verbose) dbglog.debug("OAuth succeeded. Security Passed.");

            //@@Clear any previous failure
            session.name('policy').setVariable('fw/next-policy', '_DEFAULT_');
            session.name('policy').deleteVariable('flow/exception');
            session.name('api').deleteVariable('error-name');
            session.name('api').deleteVariable('error-message');
            session.name('api').deleteVariable('error-protocol-reason-phrase');
            session.name('api').deleteVariable('error-protocol-response');
            session.name('_apimgmt').deleteVariable('error/www-authenticate');
            sm.errorProtocolResponse = '';
            sm.errorProtocolReasonPhrase = '';
        } else {
           //@@ Process the next policy
           if (verbose) dbglog.debug("OAuth succeeded. Looking for additional policy to process.");
           processPolicy();
        }
    }
}

function runbasicAuth()
{
    //@@ Run the rule ourselves.
    //@@ Call rull for doing basic auth
    multistep.callRule("webapi-policy-basicauth", session.input, session.output, basicAuthCallback);
}

function basicAuthCallback(err)
{
    if (err) {
        if (verbose) dbglog.debug("Basic Auth Identity failed.");
        //@@ Mark the current AND as false, and move on to the next policy
        indexOr++;
        startORProcessing();
    }
    else
    {
        indexAnd++;
        var policySet = Object.keys(policyProperties[indexOr]);
        if (indexAnd >= policySet.length) {
            //@@ We went thru all the policies, and all succeeded.
            //@@ Success
            if (verbose) dbglog.debug("Basic Auth succeeded. Security Passed.");

            //@@Clear any previous failure
            session.name('policy').setVariable('fw/next-policy', '_DEFAULT_');
            session.name('policy').deleteVariable('flow/exception');
            session.name('api').deleteVariable('error-name');
            session.name('api').deleteVariable('error-message');
            session.name('api').deleteVariable('error-protocol-reason-phrase');
            session.name('api').deleteVariable('error-protocol-response');
            session.name('_apimgmt').deleteVariable('error/www-authenticate');
            sm.errorProtocolResponse = '';
            sm.errorProtocolReasonPhrase = '';
        } else {
           //@@ Process the next policy
           if (verbose) dbglog.debug("Basic Auth succeeded. Looking for additional policy to process.");
           processPolicy();
        }
    }
}

//@@ Generate XML from a JSON Policy object.
function GenerateXML(type, name, object)
{
    var xml = '<policy type="' + type + '" name="' + name + '">\n';
    xml += '<properties>';
    for (var childName in object)
    {
      if (object.hasOwnProperty(childName)) {
        xml += '<property name="' + childName + '">' + object[childName] + '</property>\n';
      }
    }
    xml += '</properties>';
    xml += '</policy>\n';
    return xml;
}
