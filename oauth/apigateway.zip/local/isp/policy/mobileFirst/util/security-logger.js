// ***************************************************** {COPYRIGHT-TOP} ***
//* Licensed Materials - Property of IBM
//* 5725-L30
//*
//* (C) Copyright IBM Corporation 2016
//*
//* US Government Users Restricted Rights - Use, duplication, or
//* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
// ********************************************************** {COPYRIGHT-END}**


'use strict';

var apim = require('local:///isp/policy/apim.custom.js');

var SecurityLogger = {
        'error' : function error(message){apim.console.error(message);},
        'debug' : function debug(message){apim.console.debug(message);},
        'warn' : function warn(message){apim.console.warn(message);},
}

exports = module.exports = SecurityLogger;
