// ***************************************************** {COPYRIGHT-TOP} ***
//* Licensed Materials - Property of IBM
//* 5725-L30
//*
//* (C) Copyright IBM Corporation 2016
//*
//* US Government Users Restricted Rights - Use, duplication, or
//* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
// ********************************************************** {COPYRIGHT-END}**

var hm = require('header-metadata');
var urlopen = require('urlopen');
var sm = require('service-metadata');

sm.mpgw.skipBackside = true;
let mfpHeaders = readMfpHeaderData();
if (!mfpHeaders) {
    sendErrorResponse("MISSING_INFORMATION");
}
else {
    let options = createOptionsForOutboundMfpRequest(mfpHeaders);
    urlopen.open(options, function (error, response) {
        if (error) {
            // TODO infer connection / TLS errror tyep / timeout
            sendErrorResponse("REQUEST_SENT_FAILED");
        } else {
            var mfpStatusCode = response.statusCode;
            var mfpDateHeaderResponse = response.headers['Date'];
            response.readAsJSON(function (error, jsonResponse) {
                if (error) {
                    sendErrorResponse("JSON_READ_FAILED");
                } else {
                    let TTL = extractTTLfromResponse(mfpHeaders.xMfpCacheTypeHeader, jsonResponse);
                    updateSuccessfulCacheResposne(mfpDateHeaderResponse, TTL, jsonResponse);
                    hm.response.statusCode = mfpStatusCode;
                    session.output.write(jsonResponse);
                }
            });
        }
    });
}


function sendErrorResponse(errorReason){
    hm.response.statusCode = 500;
    hm.response.set('MFP-Cache-Service-Error', errorReason);
    session.output.write(errorReason);
}

function createOptionsForOutboundMfpRequest(mfpHeaders) {
    let options = {
        target: mfpHeaders.xMfpUrlHeader,
        method: 'post',
        headers: {
            "Authorization": mfpHeaders.xazHeader,
        },
        contentType: 'application/x-www-form-urlencoded',
        data: mfpHeaders.xMfpDataHeader
    };

    let certificate = mfpHeaders.xMfpTlsProfileHeader;
    if (certificate) {
        //options.sslProxyProfile = certificate;
        options.sslClientProfile = certificate;
    }

    return options;
}

function extractTTLfromResponse(xMfpCacheTypeHeader, jsonData) {
    let ttl = 0;
    if (xMfpCacheTypeHeader === 'token') {
        ttl = jsonData.expires_in;
        if (ttl) {
            // Confidence for the possibility that the confidential client token
            // would be invalid in introspection phase.
            if (ttl > 30) {
                ttl = ttl - 30;
            }
        }

        if (!ttl) {
            ttl = 0;
        }
    }
    else if (xMfpCacheTypeHeader === 'introspect') {
        let isActive = jsonData.active;
        if (isActive && isActive === true) {
            let exp = jsonData.exp; // for example 1465802210646 
            if (exp) {
                // Both data.exp and Date.now are since Epoch.
                ttl = Math.floor((exp - Date.now()) / 1000);
                // currently we limit the introspection data cache to only 5 minutes in order to prevent document cache fluid
                if(ttl > 300){
                    ttl = 300;
                }
            }
        }
    }

    if(ttl < 0){
        ttl = 0;
    }
    return ttl;
}

function updateSuccessfulCacheResposne(mfpDateHeaderResponse, TTL, jsonData) {
    // DataPower doesn't cache response with Vary header
    if (hm.response.get('Vary')) {
        hm.response.remove('Vary');
    }

    // MPGWs in skip-backside don't inject a Date header, so inject one manually (It's in GMT format)
    hm.response.set('Date', mfpDateHeaderResponse);
    // DataPower actully uses only the max-age TTL value for calculating the TTL
    hm.response.set('Cache-Control', 'max-age=' + TTL);
}

function readMfpHeaderData() {
    let mfpHeaders = {};
    mfpHeaders.xazHeader = hm.current.get('x-Authorization');
    if (!mfpHeaders.xazHeader) {
        // error flow
        return undefined;
    }

    mfpHeaders.xMfpDataHeader = hm.current.get('x-mfp-data');
    if (!mfpHeaders.xMfpDataHeader) {
        // error flow
        return undefined;
    }

    mfpHeaders.xMfpUrlHeader = hm.current.get('x-mfp-url');
    if (!mfpHeaders.xMfpUrlHeader) {
        // error flow
        return undefined;
    }

    mfpHeaders.xMfpCacheTypeHeader = hm.current.get('x-mfp-cache-type');
    if (!mfpHeaders.xMfpCacheTypeHeader) {
        // error flow
        return undefined;
    }

    mfpHeaders.xMfpTlsProfileHeader = hm.current.get('x-mfp-tls-profile');
    if (!mfpHeaders.xMfpTlsProfileHeader) {
        // error flow
        return undefined;
    }

    return mfpHeaders;
}
