// ***************************************************** {COPYRIGHT-TOP} ***
// Licensed Materials - Property of IBM
// 5725-L30, 5725-Z22, 5725-Z63, 5725-U33
//
// (C) Copyright IBM Corporation 2016, 2017
//
// US Government Users Restricted Rights - Use, duplication, or
// disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
// ********************************************************** {COPYRIGHT-END}**
var apim = require('local:///isp/policy/apim.custom.js');
var verbose = apim.verbose;

var typeMap = {};
typeMap["string"] = "string";
typeMap["object"] = "object";
typeMap["array"] = "array";
typeMap["number"] = "decimal";
typeMap["number|double"] = "double";
typeMap["number|float"] = "float";
typeMap["boolean"] = "boolean";
typeMap["integer"] = "integer";
typeMap["integer|int32"] = "int";
typeMap["integer|uint32"] = "int";

// Non-standard, often encountered in the wild
typeMap["int"] = "int";
typeMap["date-time"] = "dateTime";
typeMap["time"] = "time";
typeMap["date"] = "date";

// String formats
typeMap["string|uri"] = "anyURI";
typeMap["string|email"] = "string";
typeMap["string|phone"] = "string";
typeMap["string|date-time"] = "dateTime";
typeMap["string|date"] = "date";
typeMap["string|time"] = "time";
typeMap["string|utc-millisec"] = "long";
typeMap["string|regex"] = "string";
typeMap["string|color"] = "string";
typeMap["string|style"] = "string";

var required;

function determineXSDType(value) {
    var xsdType;

    if (value.enum === undefined) {
        var type = value.type;
        var format = value.format;
        if (verbose) apim.console.debug('determineXSDType: type is [' + type + '] and format is [' + format + ']');
        // the element may not have a type defined but if it has a child 'properties' then it is an object
        if (type === undefined) {
            if (verbose) apim.console.debug('determineXSDType: we have undefined type, checking for explicit object type');
            if (value.hasOwnProperty('properties')) {
                if (verbose) apim.console.debug('determineXSDType: we have a properties element so seting the type to be an object');
                type = 'object';
            }
        }
        xsdType = getType(type, format);
    } else {
        xsdType = 'enum';
    }
    if (verbose) apim.console.debug('determineXSDType: Determining xsd type which is [' + xsdType + ']');
    return xsdType;
}

function getType(type, format) {
    var key = (type + (format !== undefined ? ("|" + format) : "")).toLowerCase();
    var xsdType = typeMap[key];
    return xsdType;
}

var xmlname;

function process(schema) {
    var xsd = '';
    if (verbose) apim.console.debug('process: in process');
    if ((typeof schema === "string") && (schema !== null)) {
        xsd += process(JSON.parse(schema));
    } else {
        var xmlData = getNameOfRoot(schema);
        xsd += setupInitialDocument(xmlData);
        if (schema.hasOwnProperty('allOf')) {
            // We need to handle the allOf case 
            if (verbose) apim.console.debug('process: we have an allOf');
            var allOf = schema.allOf;
            if (isArray(allOf)) {
                xsd += '<xs:element><xs:complexType><xs:sequence>';
                allOf.forEach(function(x) {
                    var tempXmlData = getNameOfRoot(x);
                    xsd = replaceNameOfTopElement(xsd, tempXmlData);
                    var required = x.required;
                    var properties = x.properties;
                    if (properties!==undefined) {
                        xsd = traverseObject(properties, xsd, required);
                    } else {
                        //createAnyElement(schemaSequence);
                    }

                });
                xsd += '</xs:sequence></xs:complexType></xs:element>';
            }
        } else {
            var type = schema.type;
            if (type === 'array') {
                if (verbose) apim.console.debug('process: we have a array type as the top level item');
                var required = schema.required;
                var retVal = processValue('', schema, required);
                xsd += retVal.xsd;
            } else if (type === 'object' || schema.hasOwnProperty('properties')) {
                type = 'object';
                var required = schema.required;
                if (schema.hasOwnProperty('properties')) {
                    var properties = schema.properties;
                    //console.log('process: has required ['+required+']')
                    if ((typeof properties === "object") && (properties !== null)) {
                        // create the XSD treating the SOAP Body as the complete schema to allow validation of just the SOAP Body
                        if (xmlData.isSOAPxsd)
                            xsd = traverseObject(properties.Envelope.properties.Body.properties, xsd, properties.Envelope.properties.Body.required);
                        else
                            xsd = traverseObject(properties, xsd, required);
                    }
                }
            } else {
                // error
            }
        }
        xsd += completeDocument(xmlData);
    }
    return xsd;
}

function replaceNameOfTopElement(xsd, xmlData) {
    if (verbose) {
      apim.console.debug('replaceNameOfTopElement: xmlData [' + JSON.stringify(xmlData) + ']');
      apim.console.debug('replaceNameOfTopElement: inputted xsd [' + xsd + ']');
    }

    if (xmlData.name !== undefined && xmlData.name.length>0) {
        // find first occurance of <xs:element name="
        var index1 = xsd.indexOf('<xs:element name="');
        if (index1 >= 0) {
            // we have found a name, so find the end of the name 
            index1 += '<xs:element name="'.length; 
            var index2 = xsd.indexOf('"><xs:complexType>');
            if (index2 >= 0) {
                // we have the end of the name 
                // so replace value between index1 and index2 with the new name
                xsd = xsd.substring(0,index1)+xmlData.name+xsd.substring(index2, xsd.length);
            }
        } else {
            // we dont have a name so insert the name
            index1 = xsd.indexOf('<xs:element');
            if (index1 >= 0) {
                xsd = xsd.replace('<xs:element', '<xs:element name="'+xmlData.name+'"' );
            }
        }
    } else {
        // we dont have a name so insert the name
        var index1 = xsd.indexOf('<xs:element name="');
        if (index1 < 0) {
            if (verbose) apim.console.debug('replaceNameOfTopElement: the name of the root element is not set');
            index1 = xsd.indexOf('<xs:element');
            if (index1 >= 0) {
                xsd = xsd.replace('<xs:element', '<xs:element name="object"' );
            }
        }
    }
    if (verbose) apim.console.debug('replaceNameOfTopElement: updated xsd [' + xsd + ']');
    return xsd;
}

function setupInitialDocument(xmlData) {
    var xsd = '<?xml version="1.0" encoding="UTF-8"?><xs:schema xmlns:xs="http://www.w3.org/2001/XMLSchema"';
    xsd += ' attributeFormDefault="unqualified" elementFormDefault="qualified"';
    if (xmlData.namespace!==undefined) {
        xsd += ' targetNamespace="'+xmlData.namespace+'"';
        if (xmlData.prefix!==undefined) {
            xsd += ' xmlns:'+xmlData.prefix+'="'+xmlData.namespace+'">';
        } else {
            xsd += '>';
        }
    } else {
        xsd += '>';
    }
    if (xmlData.name !== undefined && xmlData.name.length>0) {
        xsd += '<xs:element name="' + xmlData.name + '"><xs:complexType><xs:sequence>';
    }
    return xsd;
}

function completeDocument(xmlData) {
    var xsd = '';
    if (xmlData.name !== undefined && xmlData.name.length>0) {
        xsd += '</xs:sequence></xs:complexType></xs:element>';
    }
    xsd += '</xs:schema>';
    return xsd;
}

function isArray(o) {
    return Object.prototype.toString.call(o) === "[object Array]";
}

function traverseArray(arr, xsd, required) {
    arr.forEach(function(x) {
        if (isArray(x)) {
            xsd = traverseArray(x, xsd, required);
        } else if ((typeof x === "object") && (x !== null)) {
            xsd = traverseObject(x, xsd, required);
        }
    });
    return xsd;
}

function traverseObject(obj, parentXsd, required) {
    if (verbose) {
      apim.console.debug('\n\ntraverseObject: obj = [' + JSON.stringify(obj) + ']');
      apim.console.debug('traverseObject: parentXsd = [' + parentXsd + ']');
    }

    var xsd = '';
    var attr = '';
    for ( var key in obj) {
        if (obj.hasOwnProperty(key)) {
            var value = obj[key];
            if (verbose) apim.console.debug('traverseObject: about to process key ['+key+'] with value ['+value+'] and required ['+required+']');
            var retVals = processValue(key, value, required);
            if (verbose) apim.console.debug('traverseObject: finished processing key ['+key+'] with value ['+value+'] and required ['+required+']');
            xsd += retVals.xsd;
            if (retVals.attr!==undefined) {
                attr += retVals.attr;
            }
        }
    }
    if (verbose) {
      apim.console.debug('\n\ntraverseObject: xsd  = [' + xsd + ']');
      apim.console.debug('traverseObject: attr = [' + attr + ']');
    }

    if (attr.length > 0) {
        parentXsd = insertIntoParent(parentXsd, attr);
    }
    parentXsd += xsd;
    //console.log('traverseObject: parentXsd(after) = [' + parentXsd + ']\n');
    return parentXsd;
}

function insertIntoParent(parentXsd, attr) {
    var COMPLEXTYPE = '<xs:complexType>';
    //console.log('insertIntoParent: parentXsd = [' + parentXsd + ']\n');
    //console.log('insertIntoParent: attr = [' + attr + ']\n');
    var index = parentXsd.lastIndexOf(COMPLEXTYPE);
    if (index > 0) {
        index += COMPLEXTYPE.length;
        parentXsd = [parentXsd.slice(0, index), attr, parentXsd.slice(index)].join('');
    } else {
        parentXsd += attr;
    }
    //console.log('insertIntoParent: parentXsd(after) = [' + parentXsd + ']\n');
    return parentXsd;
}

function processValue(key, value, required) {
    var xsd = '';
    var attr = '';
    var valueType = Object.prototype.toString.call(value);
    if (verbose) {
      apim.console.debug('processValue: [' + key + '] with value [' + (value == '[object Object]' ? JSON.stringify(value) : value) + '"]');
      apim.console.debug('processValue: [' + key + '] with required [' + (required !== undefined ? JSON.stringify(required) : 'undefined') + ']');
    }

    if (key == 'properties') {
        if (verbose) apim.console.debug('processValue: [' + key + '] is properties - traversing object');
        xsd = traverseObject(value, xsd, required);
    }
    var xsdType = determineXSDType(value)
    if (verbose) apim.console.debug('processValue: [' + key + '] has xsdType ['+xsdType+']'); 
    if (xsdType !== undefined) {
        var arrayXml = value.xml;
        var isAttribute = false;
        var wrapped = false; // default wrapped to be false
        var wrapname;
        var namespace;
        var prefix;
        var itemName = key;
        var isAttribute = false;
        
        if (arrayXml !== undefined) {
            if (arrayXml.hasOwnProperty("name")) {
                itemName = arrayXml.name;
            }
            if (arrayXml.hasOwnProperty("namespace")) {
                namespace = arrayXml.namespace;
            }
            if (arrayXml.hasOwnProperty("prefix")) {
                prefix = arrayXml.prefix;
            }
            if (arrayXml.hasOwnProperty("attribute")) {
                isAttribute = arrayXml.attribute;
            }
            // Get the wrapped element - if exists will create an top level
            // element to include the items
            if (arrayXml.hasOwnProperty("wrapped")) {
                wrapped = arrayXml.wrapped;
            }
            if (arrayXml.hasOwnProperty("name")) {
                wrapname = arrayXml.name;
            }
        }
        
        var retXsd = '';
        switch (xsdType) {
            case 'array':
                retXsd = processArrayType(key, value, xsdType, wrapped, wrapname, isAttribute, required);
                break;
            case 'decimal':
            case 'double':
            case 'float':
            case 'integer':
            case 'int':
                retXsd = processNumberType(key, value, xsdType, isAttribute, required);
                break;
            case 'enum':
                retXsd = processEnumType(key, value, isAttribute, required);
                break;
            case 'object':
                retXsd = processObjectType(key, value, isAttribute, required);
                break;
            case 'string':
                retXsd = processStringType(key, value, isAttribute, required);
                break;
            default:
                retXsd = processDefaultType(key, value, xsdType, isAttribute, required);
                break;
        }

        if (verbose) apim.console.debug('processValue: retXsd = [' + retXsd + ']');

        if (isAttribute) {
            attr += retXsd;
        } else {
            xsd += retXsd;
        }
    }
    
    var retVals = {};
    retVals.xsd = xsd;
    retVals.attr = attr;
    
    return retVals;
}

function getStartElement(key, isAttribute, required) {
    var xsd = '';
    if (verbose) apim.console.debug('getStartElement: ['+key+'] required = [' + (required!==undefined ? JSON.stringify(required): 'undefined') + ']');
    if (isAttribute) {
        // Needs to be stored in parent object but dont know what it is!!!
        xsd += '<xs:attribute name="' + key + '"';
        if (isRequired(key, required)) {
            xsd += ' use="required"';
        }
    } else {
        if (key !== undefined && key.length>0) {
            xsd += '<xs:element name="' + key + '"' + (isRequired(key, required) ? '' : ' minOccurs="0"');
        } else {
            xsd += '<xs:element';
        }
    }
    if (verbose) apim.console.debug('getStartElement: ['+key+'] xsd = [' + xsd + ']');
    return xsd;
}

function getEndElement(isAttribute) {
    var xsd = '';
    if (isAttribute) {
        xsd += '</xs:attribute>';
    } else {
        xsd += '</xs:element>';
    }
    //console.log('getEndElement: xsd = [' + xsd + ']');
    return xsd;
}

function processStringType(key, value, isAttribute, required) {
    var xsd = '';
    xsd += getStartElement(key, isAttribute, required);
    var minimumLength = value.minLength;
    var maximumLength = value.maxLength;
    var pattern = value.pattern;
    if (minimumLength !== undefined || maximumLength !== undefined || pattern !== undefined) {
        xsd += '>';
        xsd += '<xs:simpleType><xs:restriction base="xs:string">';
        if (minimumLength !== undefined) {
            xsd += '<xs:minLength value="' + minimumLength + '"/>';
        }
        if (maximumLength !== undefined) {
            xsd += '<xs:maxLength value="' + maximumLength + '"/>';
        }
        if (pattern !== undefined) {
            xsd += '<xs:pattern value="' + pattern + '"/>';
        }
        xsd += '</xs:restriction></xs:simpleType>';
    } else {
        // we dont have any restrictions so we need to add the type to the <xs:element>
        xsd += ' type="xs:string">';
    }
    xsd += getEndElement(isAttribute);
    return xsd;
}

function processNumberType(key, value, xsdType, isAttribute, required) {
    var xsd = '';
    //console.log('processNumberType: required = ['+required+']');
    xsd += getStartElement(key, isAttribute, required);
    var minimumLength = value.minimum;
    var maximumLength = value.maximum;
    var pattern = value.pattern;
    if (minimumLength !== undefined || maximumLength !== undefined) {
        xsd += '>';
        xsd += '<xs:simpleType><xs:restriction base="xs:' + xsdType + '">';
        if (minimumLength !== undefined) {
            xsd += '<xs:minInclusive value="' + minimumLength + '"/>';
        }
        if (maximumLength !== undefined) {
            xsd += '<xs:maxInclusive value="' + maximumLength + '"/>';
        }
        xsd += '</xs:restriction></xs:simpleType>';
    } else {
        // we dont have any restrictions so we need to add the type to the <xs:element>
        xsd += ' type="xs:' + xsdType + '">';
    }
    xsd += getEndElement(isAttribute);
    return xsd;
}

function processDefaultType(key, value, xsdType, isAttribute, required) {
    var xsd = '';
    xsd += getStartElement(key, isAttribute, required);
    if (xsdType!==undefined) {
        xsd += ' type="xs:' + xsdType + '">';
    } else {
        xsd += '>';
    }
    xsd += getEndElement(isAttribute);
    return xsd;
}

function processEnumType(key, value, isAttribute, required) {
    var xsd = '';
    xsd += getStartElement(key, isAttribute, required);
    xsd += '><xs:simpleType><xs:restriction base="xs:string">';
    var enumArray = value.enum;
    for (var i = 0; i < enumArray.length; i++) {
        xsd += '<xs:enumeration value="' + enumArray[i] + '"/>';
    }
    xsd += '</xs:restriction></xs:simpleType>';
    xsd += getEndElement(isAttribute);
    return xsd;
}

function processObjectType(key, value, isAttribute, required) {
    var xsd = '';
    xsd += getStartElement(key, isAttribute, required);
    
    var curRequired = value.required;
    if (curRequired === undefined) curRequired = required;
    
    xsd += '><xs:complexType><xs:sequence';
    if (!value.hasOwnProperty("properties")) {
        if (value.hasOwnProperty("oneOf")) {
            var oneOf = value.oneOf;
            xsd += '><xs:choice maxOccurs="1" minOccurs="1">';
            xsd += processXXXOf(oneOf, curRequired);
            xsd += '</xs:choice>';
        } else if (value.hasOwnProperty("anyOf")) {
            var anyOf = value.anyOf;
            xsd += '><xs:choice minOccurs="1">';
            xsd += processXXXOf(anyOf, curRequired);
            xsd += '</xs:choice>';
        } else if (value.hasOwnProperty("allOf")) {
            var allOf = value.allOf;
            xsd += ' minOccurs="1">';
            xsd += processXXXOf(allOf, curRequired);
        } else {
            xsd += '><xs:any maxOccurs="unbounded" processContents="skip" />';
        }
    } else {
        xsd += '>';
        xsd += traverseObject(value, '', curRequired);
    }
    xsd += '</xs:sequence></xs:complexType>';
    xsd += getEndElement(isAttribute);
    return xsd;
}

function processXXXOf(xxxOf, required) {
    var xsd = '';
    if (isArray(xxxOf)) {
        xsd += traverseArray(xxxOf, xsd, required); 
    } else {
        xsd += traverseObject(xxxOf, xsd, required); 
    }
    return xsd;
}

function processArrayType(key, value, xsdType, wrapped, wrapname, isAttribute, required) {
    var itemName = key;
    var arrayItems = value.items;
    var xsd = '';
    var xml = arrayItems.xml;
    if (xml!==undefined && xml.name!==undefined) {
        itemName = xml.name;
    }

    if (wrapped) {
        if (wrapname!==undefined) {
            xsd += getStartElement(wrapname, isAttribute, required);
        } else {
            xsd += getStartElement(key, isAttribute, required);
        }
        xsd += '><xs:complexType><xs:sequence>';
    }
    
    var curRequired = value.required;
    if (curRequired === undefined) curRequired = required;
    
    var retVal = processValue(itemName, arrayItems, curRequired);
    
    var xsdRetVal = retVal.xsd; 
    //console.log('processArrayType: retXsd = [' + xsdRetVal + ']\n');
    
    // Minimum items
    var minItems = value.minItems;
    if (minItems!==undefined) {
        if (xsdRetVal.lastIndexOf(' minOccurs="0"') > -1) {
            xsdRetVal = xsdRetVal.replace(' minOccurs="0"', '');
        }
        if (arrayItems.type=='object') {
            var index = xsdRetVal.indexOf('><xs:complexType>');
        } else {
            var index = xsdRetVal.lastIndexOf('></xs:element>');
        }
        xsdRetVal = [xsdRetVal.slice(0, index), ' minOccurs="'+minItems+'"', xsdRetVal.slice(index)].join('');
    }

    // Max Items
    var maxItems = value.maxItems;
    if (arrayItems.type=='object') {
        var index = xsdRetVal.indexOf('><xs:complexType>');
    } else {
        var index = xsdRetVal.lastIndexOf('></xs:element>');
    }
    if (maxItems!==undefined) {
        xsdRetVal = [xsdRetVal.slice(0, index), ' maxOccurs="'+maxItems+'"', xsdRetVal.slice(index)].join('');
    } else {
        xsdRetVal = [xsdRetVal.slice(0, index), ' maxOccurs="unbounded"', xsdRetVal.slice(index)].join('');
    }

    xsd += xsdRetVal;
    
    if (value.hasOwnProperty('uniqueItems')) {
        var unique = value.uniqueItems;
        if (unique) {
            var uniqueStr = '<xs:unique name="unique'+itemName+'"><xs:selector xpath="'+itemName+'"/><xs:field xpath="."/></xs:unique>'; 
            if (wrapped) {
                // the element is wrapped so just add the unique element to the child 
                xsd += '</xs:sequence></xs:complexType>' + uniqueStr;
                xsd += getEndElement(isAttribute);
            } else {
                // the element is not wrapped so just add the unique element to the parent 
                var index = xsdRetVal.lastIndexOf('</xs:element>');
                xsd = [xsd.slice(0, index), uniqueStr, xsd.slice(index)].join('');
            }
        }
    } else {
        if (wrapped) {
            xsd += '</xs:sequence></xs:complexType>';
        }
    }
    
    return xsd;
}

function isRequired(key, required) {
    ////console.log('isRequired: key = [' + key + ']  required = ['+ required +']');
    var found = false;
    if (required!==undefined) {
        ////console.log('isRequired: required lenghth is '+required.length);
        for (var i=0; i<required.length; i++) {
            ////console.log('isRequired: key = [' + key + ']  required['+i+'] = ['+ required +']');
            if (required[i]==key) {
                found = true;
                break;
            }
        }
    }
    //console.log('isRequired: found key = [' + key + '] ' + found  );
    return found;
}

function searchPropertiesForNamespace(properties, xmlData) {
    for (var property in properties) {

        // No xml property means that the namespace info is inherited from the parent elemnt.  Since we
        // only support one namespace, no inheritance is currently supported, but this will be important
        // if multiple namespaces are supported in the future.
        if ((properties.hasOwnProperty(property)) && (properties[property].xml !== undefined) &&
            (properties[property].xml.namespace !== undefined)) {

            if (properties[property].xml.namespace.length > 0) {

                xmlData.namespace = properties[property].xml.namespace;

                // If we are not within a SOAP Envelope already, do the search starting from the
                // properties of the SOAP Body to produce the XSD based off the namespace of the SOAP Body
                if ((!xmlData.isSOAPxsd) && (xmlData.namespace === 'http://schemas.xmlsoap.org/soap/envelope/' ||
                                             xmlData.namespace === 'http://www.w3.org/2003/05/soap-envelope')) {

                    xmlData.isSOAPxsd = true;
                    searchPropertiesForNamespace(properties.Envelope.properties.Body.properties, xmlData);
                }
            } else if (xmlData.namespace !== undefined) {
                // The namespace is the empty string so make sure it is deleted if already set to keep from
                // setting a targetNamespace of the empty string
                delete xmlData.namespace;
            }
            // Only one namespace supported here
            break;
        }
    }
}

function getNameOfRoot(schema) {
    var xmlData = {};
    xmlData.isSOAPxsd = false;

    if (schema.xml !==undefined) {
        var xml = schema.xml;
        var xmlName = xml.name
        if (xmlName!==undefined) {
            xmlData.name = xmlName;
        }
        xmlData.namespace = xml.namespace;
        xmlData.prefix = xml.prefix;
    }

    // If namespace is undefined or empty, we need to search for a namepsace within the properties section of
    // the schema.  This is important to define the targetNamespace.  An XSD can only have one namespace, and
    // we don't currently support using multiple XSDs, so stop at the first real namespace
    if ((xmlData.namespace === undefined || xmlData.namespace.length === 0) && schema.properties !== undefined) {
        searchPropertiesForNamespace(schema.properties, xmlData);
    }

    ////console.log('XMLData = '+JSON.stringify(xmlData));
    return xmlData;
}

exports.transform = function(schema) {
    return process(schema);
}
